import sys
import os
from celery import chord
from celery import group
import tasks 
import redis
from collections import OrderedDict


if (len(sys.argv) < 2):
    print("Use the command: python3 client.py <data_dir>")

DIR=sys.argv[1]
print(sys.argv[0],"  ",sys.argv[1],"\n")


abs_files=[os.path.join(pth, f) for pth, dirs, files in os.walk(DIR) for f in files]
x=chord(tasks.getCount.s(filename) for filename  in abs_files)(tasks.reduce.s())
x.get()
















