import os
import collections, functools, operator
from pathlib import Path

app = Celery('tasks',backend='redis://localhost',broker='pyamqp://guest@localhost//')
task_annotations = {'tasks.getCount':{'celery_acks_late':True},'tasks.reduce':{'celery_acks_late':True}} 

@app.task
def getCount(filename):
        wc={}
        with open(filename, mode='r', newline='\r') as f:   
            for text in f:
                if text == '\n':
                    continue
                sp = text.split(',')[4:-2]
                tweet = " ".join(sp)  
                for word in tweet.split(" "):
                    if word not in wc:
                        wc[word] = 0
                    wc[word] = wc[word] + 1
        return wc
@app.task
def reduce(counter):
        result = dict(functools.reduce(operator.add,map(collections.Counter,counter)))
        return result










