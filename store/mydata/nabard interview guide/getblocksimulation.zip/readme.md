# READEME FOR NEW VERSION
> Date : 12th April, 2019     01:20AM

This version of getblock simulation is fully automated and has all the changes that mam told us to do.